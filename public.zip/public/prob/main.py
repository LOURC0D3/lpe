from flask import Flask, render_template, request, redirect, url_for
import uuid
import tempfile
import subprocess
import os
from shutil import rmtree

app = Flask(__name__)
HOST = '0.0.0.0'
PORT = 1234

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result')
def result():
    score = request.args.get('score')
    error = request.args.get('error')
    output = request.args.get('output')

    return render_template('result.html', score=score, error=error, output=output)

@app.route('/submit', methods=['POST'])
def submit():
    code = request.json['code']

    file_path = tempfile.mkdtemp() + '/'
    with open(file_path + 'submit.c', 'w') as f:
        f.write(code)

    result = subprocess.run(['/home/prob/executer', file_path])

    error = ''
    score = ''
    if result.returncode == 101:
        error = '런타임 에러'
    elif result.returncode == 102:
        error = '컴파일 실패'
    elif result.returncode == 103:
        error = '시간 초과'
    else:
        score = result.returncode
        output = ''
        with open(file_path + 'out', 'r') as f:
            output = f.read()

    # rmtree(file_path)
    return f"http://{HOST}:{PORT}/result?score={score}&error={error}&output={output}"
    

if __name__ == '__main__':
    app.run(host=HOST, port=PORT)
