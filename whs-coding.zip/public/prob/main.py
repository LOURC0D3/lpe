from flask import Flask, render_template, request
import uuid
import tempfile
import subprocess
import os
from shutil import rmtree

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    code = request.json['code']

    file_path = tempfile.mkdtemp() + '/'
    with open(file_path + 'submit.c', 'w') as f:
        f.write(code)

    result = subprocess.run(['/home/prob/executer', file_path])
    rmtree(file_path)

    error = ''
    score = ''
    if result.returncode == -1:
        error = '런타임 에러'
    elif result.returncode == -2:
        error = '컴파일 실패'
    elif result.returncode == -3:
        error = '시간 초과'
    else:
        score = result.returncode


    return render_template('result.html', score=score, error=error)
    

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1234)
