//gcc -o executer executer.c
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <stddef.h>
#include <string.h>
#include <sys/mman.h>

#define RUNTIME_ERROR -1
#define COMPILE_ERROR -2
#define TIMEOUT_ERROR -3
#define MAX_FILE_SIZE 1024 * 1024

void timeout()
{
    printf("Timeout\n");
    exit(TIMEOUT_ERROR);
}

void initialize()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    signal(SIGALRM, timeout);
    alarm(10);
}

int longest_common_substring(char *X, char *Y, int m, int n)
{
    int LCSuffix[m + 1][n + 1];
    int result = 0;

    for (int i = 0; i <= m; i++)
    {
        for (int j = 0; j <= n; j++)
        {
            if (i == 0 || j == 0)
                LCSuffix[i][j] = 0;
            else if (X[i - 1] == Y[j - 1])
            {
                LCSuffix[i][j] = LCSuffix[i - 1][j - 1] + 1;
                result = (result > LCSuffix[i][j]) ? result : LCSuffix[i][j];
            }
            else
                LCSuffix[i][j] = 0;
        }
    }
    return result;
}

int convert_to_score(double similarity)
{
    if (similarity == 1.0)
    {
        return 100;
    }
    else
    {
        return (int)(similarity * 100);
    }
}

double calculate_similarity(const char *expected_output, const char *actual_output)
{
    int expected_len = strlen(expected_output);
    int actual_len = strlen(actual_output);

    int common_len = longest_common_substring(expected_output, actual_output, expected_len, actual_len);

    double similarity = (double)common_len / (double)expected_len;
    return similarity;
}

int main(int argc, char *argv[])
{
    initialize();

    if (argc != 2)
    {
        printf("Usage: %s <filepath>\n", argv[0]);
        return RUNTIME_ERROR;
    }

    char *file_path = argv[1];
    char *code_path = malloc(strlen(file_path) + 5);
    char *executable_path = malloc(strlen(file_path) + 15);

    if (code_path == NULL || executable_path == NULL)
    {
        printf("Memory allocation failed.\n");
        return RUNTIME_ERROR;
    }

    strcpy(code_path, file_path);
    strcat(code_path, "submit.c");

    strcpy(executable_path, file_path);
    strcat(executable_path, "executable");

    printf("Code path: %s\n", code_path);
    printf("Executable path: %s\n", executable_path);

    FILE *fp = fopen(code_path, "r");
    if (fp == NULL)
    {
        perror("fopen");
        return RUNTIME_ERROR;
    }

    char command_line[512];
    strcpy(command_line, "gcc -o ");
    strncat(command_line, executable_path, 100);
    strcat(command_line, " ");
    strncat(command_line, code_path, 100);

    printf("Command: %s\n", command_line);

    if(popen(command_line, "r") == NULL)
    {
        perror("popen");
        return RUNTIME_ERROR;
    }

    sleep(5);
    alarm(6);
    if (access(executable_path, F_OK) == -1)
    {
        printf("Compilation failed.\n");
        return COMPILE_ERROR;
    }

    memset(command_line, 0, 512);
    strcpy(command_line, "LD_PRELOAD=/home/prob/sandbox.so ");
    strncat(command_line, executable_path, 100);
    strcat(command_line, " > ");
    strncat(command_line, file_path, 100);
    strcat(command_line, "out");
    strcat(command_line, " 2>&1 ");

    printf("Command: %s\n", command_line);
    if(popen(command_line, "r") == NULL)
    {
        perror("popen");
        return RUNTIME_ERROR;
    }
    sleep(5);
    alarm(6);

    char output_filepath[512];
    strcpy(output_filepath, file_path);
    strcat(output_filepath, "out");

    char actual_output[MAX_FILE_SIZE];
    fp = fopen(output_filepath, "r");
    if (fp == NULL)
    {
        perror("fopen");
        return RUNTIME_ERROR;
    }

    fread(actual_output, 1, MAX_FILE_SIZE-10, fp);
    fclose(fp);

    if (strcmp(actual_output, "Bad system call\n") == 0)
    {
        printf("Bad system call detected.\n");
        return RUNTIME_ERROR;
    }

    double similarity = calculate_similarity("Hello", actual_output);

    printf("Expected Output: %s\n", "Hello");
    printf("Actual Output: %s\n", actual_output);
    printf("Similarity: %.2f\n", similarity);

    int score = convert_to_score(similarity);
    printf("Score: %d\n", score);

    return score;
}
